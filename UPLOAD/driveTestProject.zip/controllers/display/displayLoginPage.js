// Controller to display Login Page

module.exports = (req, res) => {
    res.render('login',{message:null})
}